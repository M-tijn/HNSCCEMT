require(usethis)
use_data_raw()

EMTPred <- function(expr, extended = F, hist = F){
  genes <- unique(c(models$keygenes$coefnames, models$auc$coefnames, models$bor$coefnames))
  missing_genes <- genes[-which(genes %in% rownames(expr))]
  if(length(missing_genes) > 0){
    expr[missing_genes,] <- 0
  }

  probs.mesenchymal <- predicted <- as.data.frame(matrix(data = NA, nrow = ncol(expr), ncol = length(models), dimnames = list(colnames(expr), names(models))))
  for(i in 1:length(models)){
    predicted[,i] <- predict(models[[i]], t(expr))
    probs.mesenchymal[,i] <- as.data.frame(predict(models[[i]], t(expr), type = "prob"))[,2]
    if(hist==T){hist(probs.mesenchymal[,i], breaks = 20, xlab = "Probability of being Mesenchymal", main = colnames(predicted)[i])}
    probs.mesenchymal$combined <- rowMeans(probs.mesenchymal[, c("keygenes", "bor", "auc")])
    predicted$combined <- factor(ifelse(probs.mesenchymal$combined > 0.5, "MES", "EPI"))
  }
  if(extended==T){
    result <- list(pred_class = predicted, pred_probs = probs.mesenchymal)
  } else {
    result <- as.data.frame(matrix(data = NA, ncol = 2, nrow = nrow(predicted), dimnames = c(list(rownames(predicted), c("class", "score") ))))
    result$class <- predicted$combined
    result$score <- probs.mesenchymal$combined
  }

  return(result)
}
